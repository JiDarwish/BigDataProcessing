In the last part of this assignment you will practice your functional programming skills by processing a dataset.
Apply all techniques you have learned to derive the desired information from the data.

This part is worth 40 points.
